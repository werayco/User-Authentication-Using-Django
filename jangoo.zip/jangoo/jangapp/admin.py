from django.contrib import admin
from .models import posts

# Register your models here.
admin.site.register(posts)
