from django.contrib import admin
from .forms import UserRegform
# Register your models here.
# admin.site.register(UserRegform)
